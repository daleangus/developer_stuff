import random
import sys
import numpy as np
import pandas as pd
from keras.layers import Dense, Dropout
from keras.models import Sequential
from keras.optimizers import Adamax
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from pandas.api.types import CategoricalDtype
from sklearn.preprocessing import StandardScaler, RobustScaler
from itertools import combinations
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

filename = 'sigmoid_standard-scaler'

def main(start, end):
    rw = pd.read_csv("data/winequality-red.csv", sep=";")
    ww = pd.read_csv("data/winequality-white.csv", sep=";")
    ww['type'] = '0'
    rw['type'] = '1'

    data = rw.append(ww)

    for num_features in range(start, end):
        print('\nDoing: ' + str(num_features))
    #         for i in range(10):
    #             # kerasclassifier(data, num_features, exp)
    #             # nn_softmax(data, num_features, exp)
        nn_sigmoid(data, num_features, ss=True)  # uses StandardScaler


def pick_features(data, num_features, one_hot=True, binary=False):
    if one_hot:
        label = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        # label = [3, 4, 5, 6, 7, 8]
        dummies = data['quality'].astype(CategoricalDtype(categories=label))
        dummies = pd.get_dummies(dummies, prefix='quality', prefix_sep='_')
        data = pd.concat([data, dummies], axis=1)
        label_names = []
        for i in label:
            label_names.append('quality_' + str(i))
    else:
        if (binary):
            label_names = ['type']
        else:
            label_names = ['quality']

    comb = []
    for i in list(combinations(range(1, 12), num_features)):
        comb.append(i)

    return data, label_names, comb


def nn_sigmoid(data, num_features, ss=False):
    column_names_lookup = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides',
                           'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']

    data, label_names, comb = pick_features(data, num_features, one_hot=False, binary=True)
    #override
    comb = [(7,5)]
    for columns in comb:
        column_names = []
        for i in columns:
            column_names.append(column_names_lookup[i-1])
        print("\n{0}\n".format(column_names))

        if ss:
            print("Using StandardScaler")
            X = StandardScaler().fit_transform(np.array(data[column_names]))
            # X = RobustScaler().fit_transform(np.array(data[column_names]))
        else:
            X = data[column_names]

        y = np.array(data[label_names])

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=43)
        model = Sequential()
        model.add(Dense(128, activation='relu', input_dim=X_train.shape[1], kernel_initializer='he_normal'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(y_train.shape[1], activation='sigmoid'))

        # opt = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
        # opt = SGD(lr=0.001, decay=1e-6)
        opt = Adamax(lr=0.005, beta_1=0.9, beta_2=0.999)
        # opt = RMSprop(lr=.002, rho=0.9)
        model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])

        history = model.fit(X_train, y_train, epochs=200, batch_size=32, verbose=0, validation_split=.3)
        #predictions = model.predict(X_test)
        score = model.evaluate(X_test, y_test, batch_size=1)

        #
        # f = open('nn_' + filename + '_' + str(num_features) + '.txt', 'a')
        # f.write('[' + ', '.join(column_names) + "] - " + "Score: " + str(model.metrics_names) + " " + str(score) + "\n")
        # f.close()

        figure = plt.figure(figsize=(10, 7))
        h = .02
        x_min, x_max = X[:, 0].min() - .5, X[:, 0].max() + .5
        y_min, y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
        xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                             np.arange(y_min, y_max, h))
        i=1
        cm = plt.cm.YlOrRd
        cm_bright = ListedColormap(['#fbff00', '#ff0000'])
        ax = plt.subplot(2, 1 + 1, i)

        ax.set_title("Input data")
        # Plot the training points
        ax.scatter(X_train[:, 0], X_train[:, 1],  c=np.array(y_train[:, 0], dtype=float), cmap=cm_bright,
                   edgecolors='k')
        # Plot the testing points
        ax.scatter(X_test[:, 0], X_test[:, 1],  c=np.array(y_test[:, 0], dtype=float), cmap=cm_bright, alpha=0.6,
                   edgecolors='k')
        ax.set_xlim(xx.min(), xx.max())
        ax.set_ylim(yy.min(), yy.max())
        ax.set_xticks(())
        ax.set_yticks(())
        i += 1
        ax = plt.subplot(2, 1 + 1, i)

        Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 0]

        # Put the result into a color plot
        Z = Z.reshape(xx.shape)
        ax.contourf(xx, yy, Z, cmap=cm, alpha=.8)

        # Plot the training points
        ax.scatter(X_train[:, 0], X_train[:, 1], c=np.array(y_train[:, 0], dtype=float), cmap=cm_bright,
                   edgecolors='k')
        # Plot the testing points
        ax.scatter(X_test[:, 0], X_test[:, 1], c=np.array(y_test[:, 0], dtype=float), cmap=cm_bright,
                   edgecolors='k', alpha=0.6)

        ax.set_xlim(xx.min(), xx.max())
        ax.set_ylim(yy.min(), yy.max())
        ax.set_xticks(())
        ax.set_yticks(())
        ax.set_title('Binary Classifier')
        ax.text(xx.max() - .3, yy.min() + .3, ('%.2f' % score[1]).lstrip('0'),
                size=15, horizontalalignment='right')
        plt.xlabel(column_names[0])
        plt.ylabel(column_names[1])
        #plt.tight_layout()
        plt.show()


if __name__ == '__main__':
    if (len(sys.argv)==3):
        start = int(sys.argv[1])
        end = int(sys.argv[2])
    elif (len(sys.argv)==2):
        start = int(sys.argv[1])
        end = start + 1
    else:
        start=11
        end=start+1
    main(start, end)
