import random

import numpy as np
import pandas as pd
from keras.layers import Dense, Dropout
from keras.models import Sequential
from keras.optimizers import Adamax, RMSprop, SGD, Adam
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from pandas.api.types import CategoricalDtype
from sklearn.preprocessing import StandardScaler, RobustScaler
from itertools import combinations
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from keras.utils import plot_model
from keras import metrics

#filename = 'sigmoid_standard-scaler'
dataset = "rw"
filename = dataset + '_standard-scaler'
# invalid_rnd = [0, 1, 6, 15, 19, 21, 24, 28, 32, 34, 36, 39, 50, 52, 54, 62, 64, 67, 70, 75, 76, 80, 82, 84, 86, 88, 93, 94, 95, 99]
# done_rnd = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99]
# print(", ".join(map(str, np.unique(invalid_rnd))))
# print(", ".join(map(str, np.unique(done_rnd))))


def main():
    rw = pd.read_csv("./data/winequality-red.csv", sep=";")
    ww = pd.read_csv("./data/winequality-white.csv", sep=";")
    ww['type'] = '0'
    rw['type'] = '1'

    #data = rw.append(ww)
    data = (ww, rw)[dataset=='rw']

    for num_features in range(2, 12):
        print('\nDoing: ' + str(num_features))
    #         for i in range(10):
    #             # kerasclassifier(data, num_features, exp)
    #             # nn_softmax(data, num_features, exp)
        #target_acc=(0.955, .885)[dataset=='ww']
        #while True:
            #print(', '.join(map(str, invalid_rnd)))
        ret_acc = nn_softmax(data, num_features, ss=True)
        #if (ret_acc >= target_acc):
        #break
            # if len(done_rnd) >=100:
            #     break
        #nn_sigmoid(data, num_features, ss=True)  # uses StandardScaler


def pick_features(data, num_features, one_hot=True, binary=False):
    if one_hot:
        label = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        # label = [3, 4, 5, 6, 7, 8]
        dummies = data['quality'].astype(CategoricalDtype(categories=label))
        dummies = pd.get_dummies(dummies, prefix='quality', prefix_sep='_')
        data = pd.concat([data, dummies], axis=1)
        label_names = []
        for i in label:
            label_names.append('quality_' + str(i))
    else:
        if (binary):
            label_names = ['type']
        else:
            label_names = ['quality']

    comb = []
    for i in list(combinations(range(1, 12), num_features)):
        comb.append(i)

    return data, label_names, comb


def kerasclassifier(data, num_features, exp):
    data, column_names, label_names, features = pick_features(data, num_features, exp, True)
    if len(column_names) == 0:
        return

    def baseline_model():
        # create model
        model = Sequential()
        model.add(Dense(128, input_dim=len(features), activation='relu'))
        model.add(Dense(128, input_dim=len(features), activation='relu'))
        model.add(Dense(128, input_dim=len(features), activation='relu'))
        model.add(Dense(128, input_dim=len(features), activation='relu'))
        model.add(Dense(128, input_dim=len(features), activation='relu'))
        model.add(Dense(len(label_names), activation='softmax'))
        # Compile model
        model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        return model

    estimator = KerasClassifier(build_fn=baseline_model, epochs=100, batch_size=5, verbose=0)
    kfold = KFold(n_splits=2, shuffle=True)
    X = data[column_names].values
    y = data[label_names].values
    results = cross_val_score(estimator, X, y, cv=kfold)

    print("Baseline: %.2f%% (%.2f%%)" % (results.mean() * 100, results.std() * 100))
    f = open('report_' + str(num_features) + '.txt', 'a')
    f.write('[' + ', '.join(column_names) + "] - " + "Baseline: %.2f%% (%.2f%%)" % (
    results.mean() * 100, results.std() * 100) + "\n")
    f.close()


def top2(predictions, y):
    numpredictions = predictions.shape[0]
    sortedindex = []
    for n in range(numpredictions):
        sortedindex.append(np.argsort(predictions[n])[::-1])
    sortedindex = np.stack(sortedindex)

    count = 0
    for n in range(numpredictions):
        if (y[n][sortedindex[n][0]] == 1 or y[n][sortedindex[n][1]] == 1):
            count += 1

    accuracy = count / numpredictions
    return accuracy


def nn_sigmoid(data, num_features, ss=False):
    column_names_lookup = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides',
                           'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']

    data, label_names, comb = pick_features(data, num_features, one_hot=False, binary=True)
    #override
    comb = [(7,5)]
    for columns in comb:
        column_names = []
        for i in columns:
            column_names.append(column_names_lookup[i-1])
        print("\n{0}\n".format(column_names))

        if ss:
            print("Using StandardScaler")
            X = StandardScaler().fit_transform(np.array(data[column_names]))
            # X = RobustScaler().fit_transform(np.array(data[column_names]))
        else:
            X = data[column_names]

        y = np.array(data[label_names])

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=20)
        model = Sequential()
        model.add(Dense(128, activation='relu', input_dim=X_train.shape[1], kernel_initializer='he_normal'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation='relu'))
        model.add(Dropout(0.5))
        model.add(Dense(y_train.shape[1], activation='sigmoid'))

        # opt = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
        # opt = SGD(lr=0.001, decay=1e-6)
        opt = Adamax(lr=0.005, beta_1=0.9, beta_2=0.999)
        # opt = RMSprop(lr=.002, rho=0.9)
        model.compile(loss='binary_crossentropy', optimizer=opt, metrics=['accuracy'])

        history = model.fit(X_train, y_train, epochs=200, batch_size=32, verbose=0, validation_split=.2)
        #predictions = model.predict(X_test)
        score = model.evaluate(X_test, y_test, batch_size=1)

        #
        f = open('output/' + 'nn_' + filename + '_' + str(num_features) + '.txt', 'a')
        f.write('[' + ', '.join(column_names) + "] - " + "Score: " + str(model.metrics_names) + " " + str(score) + "\n")
        f.close()

        figure = plt.figure(figsize=(10, 7))
        h = .02
        x_min, x_max = X[:, 0].min() - .5, X[:, 0].max() + .5
        y_min, y_max = X[:, 1].min() - .5, X[:, 1].max() + .5
        xx, yy = np.meshgrid(np.arange(x_min, x_max, h),
                             np.arange(y_min, y_max, h))
        i=1
        cm = plt.cm.YlOrRd
        cm_bright = ListedColormap(['#fbff00', '#ff0000'])
        ax = plt.subplot(2, 1 + 1, i)

        ax.set_title("Input data")
        # Plot the training points
        ax.scatter(X_train[:, 0], X_train[:, 1],  c=np.array(y_train[:, 0], dtype=float), cmap=cm_bright,
                   edgecolors='k')
        # Plot the testing points
        ax.scatter(X_test[:, 0], X_test[:, 1],  c=np.array(y_test[:, 0], dtype=float), cmap=cm_bright, alpha=0.6,
                   edgecolors='k')
        ax.set_xlim(xx.min(), xx.max())
        ax.set_ylim(yy.min(), yy.max())
        ax.set_xticks(())
        ax.set_yticks(())
        i += 1
        ax = plt.subplot(2, 1 + 1, i)

        Z = model.predict_proba(np.c_[xx.ravel(), yy.ravel()])[:, 0]

        # Put the result into a color plot
        Z = Z.reshape(xx.shape)
        ax.contourf(xx, yy, Z, cmap=cm, alpha=.8)

        # Plot the training points
        ax.scatter(X_train[:, 0], X_train[:, 1], c=np.array(y_train[:, 0], dtype=float), cmap=cm_bright,
                   edgecolors='k')
        # Plot the testing points
        ax.scatter(X_test[:, 0], X_test[:, 1], c=np.array(y_test[:, 0], dtype=float), cmap=cm_bright,
                   edgecolors='k', alpha=0.6)

        ax.set_xlim(xx.min(), xx.max())
        ax.set_ylim(yy.min(), yy.max())
        ax.set_xticks(())
        ax.set_yticks(())
        ax.set_title('Binary Classifier')
        ax.text(xx.max() - .3, yy.min() + .3, ('%.2f' % score[1]).lstrip('0'),
                size=15, horizontalalignment='right')
        plt.xlabel(column_names[0])
        plt.ylabel(column_names[1])
        plt.tight_layout()
        plt.show()


def top_2_categorical_accuracy(ytrue, ypred):
    return metrics.top_k_categorical_accuracy(ytrue, ypred, k=2)

def nn_softmax(data, num_features, ss=False):
    column_names_lookup = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides',
                           'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']

    data, label_names, comb  = pick_features(data, num_features, one_hot=True)
    #figure = plt.figure(figsize=(10, 4))

    for columns in comb:
        column_names = []
        for i in columns:
            column_names.append(column_names_lookup[i-1])
        print("\n{0}\n".format(column_names))

        if ss:
            print("Using StandardScaler")
            X = StandardScaler().fit_transform(data[column_names])
            # X = RobustScaler().fit_transform(np.array(data[column_names]))
        else:
            X = data[column_names]

        #print(X.shape)

        y = np.array(data[label_names])

        # while True:
        #     rnd = np.random.randint(0, 100)
        #     print(rnd)
        #     if ((rnd in invalid_rnd) or (rnd in done_rnd)):
        #         pass
        #     else:
        #         break
        # done_rnd.append(rnd)
        #
        # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=rnd)
        #
        # #must have the same elements
        # ytrainindex = np.array(np.nonzero(np.sum(y_train, axis=0)))
        # ytestindex = np.array(np.nonzero(np.sum(y_test, axis=0)))
        #
        # if ytrainindex.shape[1]==ytestindex.shape[1]:
        #     if np.equal(ytrainindex[0][1], ytestindex[0][1]):
        #     # for i in range(len(ytestindex)):
        #     #     if ytrainindex[0][i]==ytestindex[0][i]:
        #         pass
        #     else:
        #         print("Invalid random state value " + str(rnd))
        #         invalid_rnd.append(rnd)
        #         return 0
        # else:
        #     print("Invalid random state value " + str(rnd))
        #     invalid_rnd.append(rnd)
        #     return 0

        rnd = (43, 27)[dataset == 'ww']
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=rnd)

        #print(X_train.shape)

        activation = 'relu'
        model = Sequential()
        model.add(Dense(128, activation=activation, input_dim=X_train.shape[1], kernel_initializer='he_normal'))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation=activation))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation=activation))
        model.add(Dropout(0.5))
        model.add(Dense(128, activation=activation))
        model.add(Dropout(0.5))
        if dataset=='ww':
            model.add(Dense(128, activation=activation))
            model.add(Dropout(0.5))
        model.add(Dense(y_train.shape[1], activation='softmax'))

        opt = SGD(lr=0.001)
        #opt = RMSprop(lr=.001)
        #opt = Adamax(lr=0.005, beta_1=0.9, beta_2=0.999)
        #opt = Adamax(lr=0.005)
        #opt = Adam(lr=0.001)

        #model.compile(loss='categorical_crossentropy', optimizer=opt, metrics=[top_2_categorical_accuracy])
        model.compile(loss='categorical_crossentropy', optimizer=opt, metrics=['accuracy'])
        #plot_model(model, to_file='model.png', show_shapes=False, rankdir='LR')

        history = model.fit(np.array(X_train), np.array(y_train), epochs=300, batch_size=128, verbose=0, validation_split=0.3)

        #red wine
        #history = model.fit(np.array(X_train), np.array(y_train), epochs=300, batch_size=128, verbose=0, validation_split=.2)
        # white wine
        #history = model.fit(np.array(X_train), np.array(y_train), epochs=200, batch_size=32, verbose=0, validation_split=.2)

        predictions = model.predict(np.array(X_test))
        score = model.evaluate(np.array(X_test), np.array(y_test), batch_size=1)

        #tk = topk(predictions, np.array(y_test))
        #print("\n{0}\n".format(tk))
        f = open('nn_' + filename + '_' + str(num_features) + '.txt', 'a')
        f.write('[' + ', '.join(column_names) + "] - " + "Score: " + str(model.metrics_names) + " " + str(
            score) + "; accuracy: " + str(score[1]) + "; rnd: " + str(rnd) + "\n")
        f.close()


        # fig, (ax2, ax1) = plt.subplots(2,1, figsize=(6.25, 4))
        # title = ('White', 'Red')[dataset == 'rw'] + ' Wine Quality - Top 2 Categorical Accuracy'
        # ax2.set_title(title)
        # ax1.plot(history.history['top_2_categorical_accuracy'])
        # ax1.plot(history.history['val_top_2_categorical_accuracy'])
        # ax1.set_ylabel('Accuracy')
        # ax1.set_xlabel('Epoch')
        # plt.text(300, .7, 'Test Score: ' + ('%.2f' % score[1]).lstrip('0'), size=15, horizontalalignment='right')
        # ax1.legend(['Train', 'Validation'], loc='upper left')
        # # Plot training & validation loss values
        # ax2.plot(history.history['loss'])
        # ax2.plot(history.history['val_loss'])
        # #ax2.title('Loss')
        # ax2.set_ylabel('Loss')
        # ax2.set_xlabel('Epoch')
        # ax2.legend(['Train', 'Validation'], loc='upper left')
        # fig.savefig(filename + "_accu.png")
        #
        # plt.close(fig)
        # plt.close('all')

        print(score[1])
    #    return score[1]


if __name__ == '__main__':
    main()
