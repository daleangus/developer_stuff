import random

import numpy as np
import pandas as pd
from keras.layers import Dense, Dropout
from keras.models import Sequential
from keras.optimizers import Adamax, RMSprop, SGD
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import train_test_split
from pandas.api.types import CategoricalDtype
from sklearn.preprocessing import StandardScaler, RobustScaler
from itertools import combinations
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from keras.utils import plot_model
from keras import metrics
import talos as ta

#filename = 'sigmoid_standard-scaler'
dataset = "ww"
filename = dataset + '_standard-scaler'

def main():
    rw = pd.read_csv("data/winequality-red.csv", sep=";")
    ww = pd.read_csv("data/winequality-white.csv", sep=";")
    ww['type'] = '0'
    rw['type'] = '1'

    #data = rw.append(ww)
    data = (ww, rw)[dataset=='rw']

    for num_features in range(11, 12):
        print('\nDoing: ' + str(num_features))
    #         for i in range(10):
    #             # kerasclassifier(data, num_features, exp)
    #             # nn_softmax(data, num_features, exp)

        scan_object, scores = nn_softmax(data, num_features, ss=True)

        pass

        #nn_sigmoid(data, num_features, ss=True)  # uses StandardScaler


def pick_features(data, num_features, one_hot=True, binary=False):
    if one_hot:
        label = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        # label = [3, 4, 5, 6, 7, 8]
        dummies = data['quality'].astype(CategoricalDtype(categories=label))
        dummies = pd.get_dummies(dummies, prefix='quality', prefix_sep='_')
        data = pd.concat([data, dummies], axis=1)
        label_names = []
        for i in label:
            label_names.append('quality_' + str(i))
    else:
        if (binary):
            label_names = ['type']
        else:
            label_names = ['quality']

    comb = []
    for i in list(combinations(range(1, 12), num_features)):
        comb.append(i)

    return data, label_names, comb


def top2(predictions, y):
    numpredictions = predictions.shape[0]
    sortedindex = []
    for n in range(numpredictions):
        sortedindex.append(np.argsort(predictions[n])[::-1])
    sortedindex = np.stack(sortedindex)

    count = 0
    for n in range(numpredictions):
        if (y[n][sortedindex[n][0]] == 1 or y[n][sortedindex[n][1]] == 1):
            count += 1

    accuracy = count / numpredictions
    return accuracy


def top_2_categorical_accuracy(ytrue, ypred):
    return metrics.top_k_categorical_accuracy(ytrue, ypred, k=2)

def nn_softmax(data, num_features, ss=False):
    column_names_lookup = ['fixed acidity', 'volatile acidity', 'citric acid', 'residual sugar', 'chlorides',
                           'free sulfur dioxide', 'total sulfur dioxide', 'density', 'pH', 'sulphates', 'alcohol']

    data, label_names, comb  = pick_features(data, num_features, one_hot=True)
    figure = plt.figure(figsize=(10, 4))

    for columns in comb:
        column_names = []
        for i in columns:
            column_names.append(column_names_lookup[i-1])
        print("\n{0}\n".format(column_names))

        if ss:
            print("Using StandardScaler")
            X = StandardScaler().fit_transform(data[column_names])
            # X = RobustScaler().fit_transform(np.array(data[column_names]))
        else:
            X = data[column_names]

        #print(X.shape)

        y = np.array(data[label_names])

        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=20)
        #print(X_train.shape)
        #print(X_test.shape)

        p = {'activation': ['relu', 'sigmoid'],
             'optimizer': ['RMSProp', 'Adamax', 'Adam'],
             'losses': ['categorical_crossentropy'],
             'batch_size': [32, 64, 128],
             'epochs': [200, 300, 400]}

        scores = []

        def yawda_model(X_train, y_train, x_val, y_val, params):
            #print(x_val.shape)
            #print(X_train.shape)
            act = params['activation']
            model = Sequential()
            model.add(Dense(128, activation=act, input_dim=X_train.shape[1], kernel_initializer='he_normal'))
            model.add(Dropout(0.5))
            model.add(Dense(128, activation=act))
            model.add(Dropout(0.5))
            model.add(Dense(128, activation=act))
            model.add(Dropout(0.5))
            model.add(Dense(128, activation=act))
            model.add(Dropout(0.5))
            model.add(Dense(y_train.shape[1], activation='softmax'))

            #opt = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
            #opt = SGD(lr=0.001, decay=1e-6)
            #opt = Adamax(lr=0.01, beta_1=0.9, beta_2=0.999)
            #opt = RMSprop(lr=.001, rho=0.9)
            model.compile(loss=params['losses'], optimizer=params['optimizer'], metrics=[top_2_categorical_accuracy])

            history = model.fit(np.array(X_train), np.array(y_train), epochs=params['epochs'], batch_size=params['batch_size'], verbose=0, validation_data=[x_val, y_val])
            scores.append(model.evaluate(np.array(X_test), np.array(y_test), batch_size=1))

            return history, model

        scan_object = ta.Scan(X_train, y_train, model=yawda_model, params=p, experiment_name='yawda', val_split=0.3)
        return scan_object, scores

if __name__ == '__main__':
    main()
